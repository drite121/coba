var $$ = Dom7;
var app = new Framework7({
	root: '#app',
	name: 'F7App',
	id: 'com.ubaya.f7app',
	panel: { swipe: 'left' },
	theme: 'ios',
	routes: [
		{
			path: '/about/',
			url: 'about.html',
		},
		 {
		    path: '/registration/',
		    url: 'registration.html',
		    on: {
		    	pageInit: function(e, page) {
		    		var calendarDefault = app.calendar.create({
					  inputEl: '#bod',
					});

					$$('#btnsubmit').on('click', function() {
						var x = new FormData($$(".form-ajax-submit")[0]);
						app.request.post('http://localhost/pmn/registrasi.php', x, function (data) {
				  				app.dialog.alert(data);
						});
					});
		    	}
		    }
		  }
	]

	function onSuccess(imageData) {
	//$$('#spanpic').hide();							
	$$('#propic').attr('src',"data:image/jpeg;base64," + imageData);			
}

function onFail(message) {
    app.dialog.alert('Failed because: '+message);
}


	$$('#btnpic').on('click',function(e) {				  
navigator.camera.getPicture(onSuccess, onFail, {quality: 100,
		  destinationType: Camera.DestinationType.DATA_URL,
		  sourceType: Camera.PictureSourceType.CAMERA,
		  encodingType: Camera.EncodingType.JPEG,
		  mediaType: Camera.MediaType.PICTURE,
		  correctOrientation: true,
		  targetWidth:100,
		  cameraDirection: Camera.Direction.FRONT
		});
function onSuccess(imageData) {	}function onFail(message) {	}
}
});

var mainView = app.views.create('.view-main',{ url: '/registration/' });