routes = [
  {
    path: '/about/',
    url: './pages/about.html',
  },
];